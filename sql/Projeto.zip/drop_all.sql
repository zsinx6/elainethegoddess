drop table comite cascade;
drop table orgao_imprensa cascade;
drop table tipo_credencial cascade;
drop table credencial cascade;
drop table profissional_imprensa cascade;
drop table limites_comite cascade;
drop table limites_oi cascade;
drop function verifica_limites_comite(integer, character varying, integer) CASCADE;
drop function verifica_limites_oi(integer, character varying) CASCADE;
